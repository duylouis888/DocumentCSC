var app = angular.module('myApp');

app.controller('StoreController', function(
            $scope,$http) {
	$http({
	    method : "GET",
	    url : "http://localhost:9000/fresherangular/product/list"
	  }).then(function mySucces(response) {
	      $scope.product = response.data;
	    }, function myError(response) {
	      alert(response.statusText);
	  });
	
	$scope.increaseItemCount = function(product) {
		var id = product.id;
		$http({
		    method : "GET",
		    url : "http://localhost:9000/fresherangular/product/increase/"+id
		  }).then(function mySucces(response) {			  
			  tempProduct = response.data;
			  for (var i=0; i<product.length; i++) {
				  if (product[i].id == tempProduct.id) {
				    product[i].available = tempProduct.available;
				    break;
				  }
				}
			  $scope.product = response.data;
		    }, function myError(response) {
		      alert(response.statusText);
		  });
	};
})