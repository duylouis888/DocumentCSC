package dao.model;

public class Student {

	private int id;
	private String fullName;
	private int phone;
	private String email;

	public Student() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public int getSex() {
		return phone;
	}

	public int getPhone() {
		return phone;
	}

	public void setPhone(int phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setSex(int phone) {
		this.phone = phone;
	}

	

	@Override
	public String toString() {
		return "Student [id=" + id + ", fullName=" + fullName + ", phone=" + phone + ", email=" + email + "]";
	}
}

