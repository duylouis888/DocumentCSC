package spring;

import java.util.List;
import java.util.Random;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.util.SocketUtils;

import spring.dao.StudentJDBCTemplate;
import spring.model.Student;

public class MainApp {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");

		StudentJDBCTemplate jdbcTemplate = (StudentJDBCTemplate) context.getBean("studentJDBCTemplate");

		System.out.println("------Records Creation--------");
		 Random r = new Random();
		
		
		for (int i = 0; i < 20; i++) {
			jdbcTemplate.create("Nguyen Van "+(char)(i), r.nextInt(24)+65, "Email@gmail"+i);
		}
		
		
		System.out.println("------Listing Multiple Records--------");
		
		List<Student> students = jdbcTemplate.listStudents();
		for (int i=0;i<10;i++) {
			System.out.println(students.get(i).toString());
		}

		
		System.out.println("----------GET Student ID 11");
		System.out.println(jdbcTemplate.getStudent(11).toString());
		
		System.out.println("----Updating Record with ID = 11 -----");
		jdbcTemplate.update(11, "Ha Noi");

		System.out.println("----Listing Record with ID = 2 -----");
		Student student = jdbcTemplate.getStudent(11);
		System.out.println(student.toString());
		
		
		System.out.println("List ALL Student");
		
		List<Student> studentall = jdbcTemplate.listStudents();
		for (int i=0;i<studentall.size();i++) {
			System.out.println(studentall.get(i).toString());
		}
		
		
	}
}
